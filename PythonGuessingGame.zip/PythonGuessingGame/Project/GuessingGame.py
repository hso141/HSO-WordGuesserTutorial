#Guessing Game
import random

playing = True #boolean
guessed = False #boolean
wordList = ["apple", "banana", "durian"] #list of strings
currentWord = "" #empty string
alreadyGuessed = [] #empty list
guess = "" #empty string
guessLimit = 12 #integer
guessCount = 0 #integer

def get_guess():
    print("Guess the word.")
    if(len(alreadyGuessed) > 0):
        displayGuessed = "Already guessed: "
        for previousGuess in alreadyGuessed:
            displayGuessed = displayGuessed + previousGuess + ", "
        print(displayGuessed)
    global guess
    guess = input("You have " + str(guessLimit - guessCount) + " guesses left.\nGuess a letter or a word: ")
    guess = guess.lower()
    if(guess == "exit"):
        exit()

def check_guess():
    guessCorrect = False
    if(guess == currentWord):
        print("\nYOU WIN! The word was: " + currentWord)
        guessCorrect = True
        global guessed
        guessed = True
    elif(len(guess) < 2):
        for char in currentWord:
            if(char == guess):
                if(not guess in alreadyGuessed):
                    alreadyGuessed.append(guess)
                guessCorrect = True
                print("The word does contain the letter: " + guess)
                break
            elif(not guess in alreadyGuessed):
                alreadyGuessed.append(guess)
    else:
        print("The word is NOT: " + guess)

    if(not guessCorrect):
        global guessCount
        guessCount += 1

def display():
    global guessed
    if(not guessed):
        displayString = ""
        for char in currentWord:
            if(char in alreadyGuessed):
                displayString = displayString + char
            else:
                displayString = displayString + "*"
        if(not "*" in displayString):
            print("\nYOU WIN! The word was: " + currentWord)
            guessed = True
        else:
            print("\n" + displayString)

#GAME LOOP
while(playing):
    alreadyGuessed = []
    guessed = False
    guess = ""
    guessCount = 0

    chosenIndex = random.randint(0, len(wordList) - 1)
    currentWord = wordList[chosenIndex]

    print("\nWord selected.\nSTART GAME")
    display()

    #Guess loop
    while(not guessed):
        get_guess()
        check_guess()
        display()
        if(guessCount >= guessLimit and not guessed):
            print("Max guesses reached. YOU LOSE.")
            guessed = True

    #exit/retry
    retry = input("Input [r] to try again\nPress [ENTER] or input any other key to exit.\n")
    if(retry == "r"):
        print("\nRESTARTING\n")
    else:
        playing = False

exit()